<?php
	session_start();

	session_unset();
	session_destroy();

	echo "Sikeres kijelentkezés <br/>";
	echo "<a href='bejelentkez.php'>Vissza a főoldalra!</a>";

?>