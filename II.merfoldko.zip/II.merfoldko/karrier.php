<?php session_start(); ?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>A&L/Kapcsolat/regisztráció</title>
    <link rel="stylesheet" href="style.css">
    <style>
        @import url('https://fonts.googleapis.com/css?family=Rubik&display=swap');
    </style>
</head>
<body>
<a href="#navigacio" class="nav-hivas">
    Menu <span></span>
</a>
<?php if(!isset($_SESSION["user"])) {
    echo '<div class="kapcsolatszoveg">
        <p class="kapcsszovg">A karrier lehetőségek megtekintéséhez kérjuk jelentkezzen be!</p>
    </div>'; 
        } else {
        echo '<div class="kapcsolatszoveg">
        <p class="kapcsszovg">Kérjük töltse ki az alábbi mezőket és mi felvesszük önnel a kapcsolatot aktuális nyitott pozícióinkkal kapcsolatban!</p>
    </div>'; 
        }
    ?>

<main style="height: 100%">
    <div class="gombclass">
        <?php if(!isset($_SESSION["user"])) {
        echo '<button class="gombok gombok1"><a href="bejelentkez.php" style="color: white">Bejelentkezés</a></button>'; } ?>
        <?php if(isset($_SESSION["user"])) {
            echo "<p style='color: white;'>Üdvözöljük " . $_SESSION["user"] . "!</p>";
            echo '<button class="gombok gombok1" name="logout"><a href="logout.php" style="color: white">Kijelentkezés</a></button>'; } ?>
    </div>
    <?php if(!isset($_SESSION["user"])) {
    echo '<img src="itjob.jpg" style="margin: 20px; height: 550px;width: 700px; border-radius: 10px 10px 10px 10px; display: block; margin-left: auto; margin-right: auto; width: 50%;">';
    } else { echo
        '<div style="color: white;
    border-radius: 5px;
    background-color: #1C1D21;
    padding-top: 50px;
    padding-right: 400px;
    padding-bottom: 50px;
    padding-left: 400px;">
        <form action="karrier.php" method="POST" enctype="multipart/form-data">
        <label>Név: <input type="text" name="nev" placeholder="Adja meg a nevét..." required/></label> <br/>
        <label>Email: <input type="text" name="email" placeholder="Adja meg az email címét..."/></label> <br/>
        <label>Telefon: <input type="tel" name="telefon" placeholder="Adja meg a telefonszámát..."/></label> <br/><br/>
        <input white;" type="hidden" name"MAX_SIZE" value="100000000"/>
        <label>Önéletrajz: <input style="color: white;" type="file" name="file" accept="pdf/*"/></label> <br/><br/>
        <label>Féynkép magadról: <input type="file" name="image" accept="image/*"/></label> <br/><br/>
        <label>Üzenet: <textarea id="subject" name="subject" placeholder="Üzenj a jelentkezéshez..." style="height:200px"></textarea> <br/>
        <input class="kuldes" type="submit" name="reg" value="Jelentkezés" /> <br/><br/>
        </form>
        </div>'; } ?>

        <?php
            if(isset($_POST["reg"])) {
                $formatum = ["jpg", "jpeg", "png"];

                $kiterjesztes = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);

                if(in_array($kiterjesztes, $formatum)) {
                    if($_FILES["image"]["error"] === 0) {
                        if($_FILES["image"]["size"] < 100000000) {
                            $dest = "Letöltések/" . $_FILES["image"]["name"];

                            move_uploaded_file($_FILES["image"]["tmp_name"], $dest);
                            echo "<p style='color: white;'>sikeres képfeltöltés!</p> <br/>";
                        } else {
                            echo "<p style='color: white;'>Túl nagy a feltölteni kívánt kép mérete!</p> <br/>";
                        } 
                    } else {
                        echo "<p style='color: white;'>Hiba történt a kép feltöltése közben!</p> <br/>";
                    }
                } else {
                    echo "<p style='color: white;'>Nem megfelelő a kép kiterjesztése!</p> <br/>";
                }
            }

            if(isset($_POST["reg"])) {
                $formatum2 = ["pdf"];

                $kiterjesztes2 = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);

                if(in_array($kiterjesztes2, $formatum2)) {
                    if($_FILES["file"]["error"] === 0) {
                        if($_FILES["file"]["size"] < 100000000) {
                            $dest2 = "Letöltések/" . $_FILES["file"]["name"];

                            move_uploaded_file($_FILES["file"]["tmp_name"], $dest2);
                            echo "<p style='color: white;'>sikeres fájlfeltöltés!</p> <br/>";
                        } else {
                            echo "<p style='color: white;'>Túl nagy a feltölteni kívánt fájl mérete!</p> <br/>";
                        } 
                    } else {
                        echo "<p style='color: white;'>Hiba történt a fájl feltöltése közben!</p> <br/>";
                    }
                } else {
                    echo "<p style='color: white;'>Nem megfelelő a fájl kiterjesztése!</p> <br/>";
                }
            }

        ?>
</main>
<footer style="text-align: center; color: white;">
  <p>Oldalért felelős: A&L Co. fejlesztő csoloprt</p> <br/>
  <p>Kapcsolat: <a href="s.laci0101@gmail.com">s.laci0101@gmail.com</a>.</p>
</footer>

<nav class="nav-kontener" id="navigacio">
    <ul class="nav" style="padding-top: 50px">
        <li><a href="szolgaltatasok.html">Szolgáltatások</a></li>
        <li><a href="referenciak.html">Projektek</a></li>
        <li><a href="tarsak.html">Ügyfelek</a></li>
        <li><a href="mi.html">Rólunk</a></li>
        <li><a href="index5.php">Kapcsolat</a></li>
        <li><a href="karrier.php" class="aktiv">Karrier</a></li>
    </ul>
</nav>

<div class="takar"></div>
<script src="style.js"></script>
</body>
</html>