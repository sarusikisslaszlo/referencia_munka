<?php session_start(); ?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>A&L/Kapcsolat/bejelentkezés</title>
    <link rel="stylesheet" href="style.css">
    <style>
        @import url('https://fonts.googleapis.com/css?family=Rubik&display=swap');
    </style>
</head>
<body>
<a href="#navigacio" class="nav-hivas">
    Menu <span></span>
</a>
<?php if(!isset($_SESSION["user"])) {
    echo '<div class="kapcsolatszoveg">
        <p class="kapcsszovg">További információkkal kapcsolatban, kérlek keressetek minket a regisztráció/bejelentkezés után kitölthető bővített és specifikusabb információs panelünkön!</p>
    </div>';
    }
?>
<main style="height: 100%">
    <div class="gombclass">
        <?php if(!isset($_SESSION["user"])) {
        echo '<button class="gombok gombok1"><a href="index5.php" style="color: white">Regisztráció</a></button>'; } ?>
        <?php if(isset($_SESSION["user"])) {
            echo "<p style='color: white;'>Üdvözöljük " . $_SESSION["user"] . "!</p>";
            echo '<button class="gombok gombok1" name="logout"><a href="logout.php" style="color: white">Kijelentkezés</a></button>'; }?>
    </div>
    <?php if(!isset($_SESSION["user"])) { echo
        '<div <div style="color: white;
    border-radius: 5px;
    background-color: #1C1D21;
    padding-top: 50px;
    padding-right: 400px;
    padding-bottom: 50px;
    padding-left: 400px;">
        <form class="form" action="bejelentkez.php" method="POST">
        <label>Felhasználónév: <input type="text" name="username" placeholder="Adja meg a felhasználónevét"/></label> <br/>
        <label>Jelszó: <input type="password" name="pwd" placeholder="Adja meg a jelszavát"/></label> <br/>
        <input class="kuldes" type="submit" name="reg" value="Bejeletkezés" />
        </form>
        </div>'; } else {
                echo '<div style="color: white;
    border-radius: 5px;
    background-color: #1C1D21;
    padding-top: 50px;
    padding-right: 400px;
    padding-bottom: 50px;
    padding-left: 400px;">
                <h1>Üdvüzöljük az A&L Co. honlapján!</h1><br/>
                <h2 style="color: white;">A következő funkciókhoz kapott hozzáférést a bejelentkezéssel: </h2><br/>
                <ul>
                    <li style="color: white;"><h3>A karrier lapon található űrlap kitöltése után felvesszük önnel a kapcsolatot és tájékoztatjuk az aktuális nyitott pozíciókkal kapcsolatban</h3></li> <br/>
                    <li style="color: white;"><h3>A regisztrációs lapon a regisztrációs felület helyén található űrlap kitöltésével üzenhet nekünk, ha van valamilyen panasza vagy ötlete az oldal működésével kapcsolatban</h3></li> <br/>
                </ul>
            </div>';
            } ?>
        <br/>


    <?php
    
    $accounts = [];
    $file = fopen("accounts.txt", "r");

    while(($line = fgets($file)) !== false) {
        $accounts[] = unserialize($line);
    }

    fclose($file);

    if(isset($_POST["reg"])) {
        $username = $_POST["username"];
        $password = $_POST["pwd"];

        foreach($accounts as $acc) {
            if($acc["username"] == $username && $acc["password"] == $password) {
                $_SESSION["user"] = $username;
                header("Location: bejelentkez.php");
            }
        }
        if(!isset($_SESSION["user"])) {
            echo '<p style="color: white;">Hibás felhasználónév vagy jelszó!</p>';
        }
    }
?>
</main>
<footer style="text-align: center; color: white;">
  <p>Oldalért felelős: A&L Co. fejlesztő csoloprt</p> <br/>
  <p>Kapcsolat: <a href="s.laci0101@gmail.com">s.laci0101@gmail.com</a>.</p>
</footer>

<nav class="nav-kontener" id="navigacio">
    <ul class="nav" style="padding-top: 50px">
        <li><a href="szolgaltatasok.html">Szolgáltatások</a></li>
        <li><a href="referenciak.html">Projektek</a></li>
        <li><a href="tarsak.html">Ügyfelek</a></li>
        <li><a href="mi.html">Rólunk</a></li>
        <li><a href="index5.php" class="aktiv">Kapcsolat</a></li>
        <li><a href="karrier.php">Karrier</a></li>
    </ul>
</nav>

<div class="takar"></div>
<script src="style.js"></script>
</body>
</html>