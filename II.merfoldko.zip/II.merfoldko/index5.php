<?php session_start() ?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>A&L/Kapcsolat/regisztráció</title>
    <link rel="stylesheet" href="style.css">
    <style>
        @import url('https://fonts.googleapis.com/css?family=Rubik&display=swap');
    </style>
</head>
<body>
<a href="#navigacio" class="nav-hivas">
    Menu <span></span>
</a>
<?php if(!isset($_SESSION["user"])) {
   echo '<div class="kapcsolatszoveg">
    <p class="kapcsszovg">További információkkal kapcsolatban, kérlek keressetek minket a regisztráció/bejelentkezés után kitölthető bővített és specifikusabb információs panelünkön!</p>
</div>';
    }
?>

<main style="height: 100%">
    <div class="gombclass">
        <?php if(!isset($_SESSION["user"])) {
        echo '<button class="gombok gombok1"><a href="bejelentkez.php" style="color: white">Bejelentkezés</a></button>'; } ?>
        <?php if(isset($_SESSION["user"])) {
            echo "<p style='color: white;'>Üdvözöljük " . $_SESSION["user"] . "!</p>";
            echo '<button class="gombok gombok1" name="logout"><a href="logout.php" style="color: white">Kijelentkezés</a></button>'; }?>
    </div>
    <?php if(!isset($_SESSION["user"])) {
    echo '
    <div style="color: white;
    border-radius: 5px;
    background-color: #1C1D21;
    padding-top: 50px;
    padding-right: 400px;
    padding-bottom: 50px;
    padding-left: 400px;">
        <form action="index5.php" method="POST">
        <label>Teljes név: <input type="text" name="nev" placeholder="Adja meg a teljes nevét..."/></label> <br/>
        <label>Felhasználónév: <input type="text" name="username" placeholder="Adjon meg egy felhasználónevet..."/></label> <br/>
        <label>Email cím: <input type="text" name="email" placeholder="Adja meg az email címét..." required/></label> <br/>
        <label>Jelszó: <input type="password" name="pwd" placeholder="Adjon meg egy jelszót..."/></label> <br/>
        <label>Jelszó megismétlése: <input type="password" name="pwdag" placeholder="Adja meg újra a jelszót..."/></label>
        <p class="sex">Nem:</p>
        <label>Férfi<input type="radio" name="sex" value="ferfi"/></label> <br/> <br/>
        <label>Nő<input type="radio" name="sex" value="no"/></label> <br/> <br/>
        <input class="kuldes" type="submit" name="reg" value="regisztráció" />
        </form>
        <br/>
    </div>'; } else {
           echo '<div style="color: white;
    border-radius: 5px;
    background-color: #1C1D21;
    padding-top: 50px;
    padding-right: 400px;
    padding-bottom: 50px;
    padding-left: 400px;">
        <form action="index5.php" method="GET">
        <label>Teljes név: <input type="text" name="nev" placeholder="Adja meg a teljes nevét..."/></label> <br/>
        <label>Email cím: <input type="text" name="email" placeholder="Adja meg az email címét..." required/></label> <br/>
        <label>Üzenet: <textarea id="subject" name="uzenet" placeholder="Üzenjen ha valn valami ötlete, hogy miben fejlődhetne az oldal..." style="height:200px"></textarea> <br/>
        <input class="kuldes" type="submit" name="uzi" value="Elküldés" />
        </form>
        <br/>
    </div>';
    }
?>
</main>
<footer style="text-align: center; color: white;">
  <p>Oldalért felelős: A&L Co. fejlesztő csoloprt</p> <br/>
  <p>Kapcsolat: <a href="s.laci0101@gmail.com">s.laci0101@gmail.com</a>.</p>
</footer>

<?php
    
    $file = fopen("accounts.txt", "r");
    $accounts =[];
    while(($line = fgets($file)) !== false)
        $accounts[] = unserialize($line);
    fclose($file);

    if(isset($_POST["reg"])) {
        $username = $_POST["username"];
        $password = $_POST["pwd"];
        $password2 = $_POST["pwdag"];

        if(isset($_POST["nev"]))
            $nev = $_POST["nev"];
        else
            die ("<b>HIBA:</b> Aja meg a nevét!");

        foreach ($accounts as $acc) {
            if($acc["username"] == $username)
                die("<b>HIBA:</b> A felhasználónév már foglalt!");
        }

        if(isset($_POST["email"]))
            $email = $_POST["email"];
        else
            die("<b>HIBA:</b> Nem adott meg email címet!");

        if(isset($_POST["sex"]))
            $sex = $_POST["sex"];

        if(strlen($password) < 5)
            die("<b>HIBA:</b> A jelszó túl rövid!");

        if($password !== $password2)
            die("<b>HIBA:</b> A két jelszó nem egyezik meg!");

        $accounts2[] = ["username" => $username, "password" => $password];

        $file2 = fopen("accounts.txt", "a-t");
        foreach ($accounts2 as $write) 
            fwrite($file2, serialize($write) . "\n"); 
        fclose($file2);

        echo "<br style='color: white;'>Sikeres regisztráció! <br/>";

        header("Location: bejelentkez.php");
    }
?>

<nav class="nav-kontener" id="navigacio">
    <ul class="nav" style="padding-top: 50px">
        <li><a href="szolgaltatasok.html">Szolgáltatások</a></li>
        <li><a href="referenciak.html">Projektek</a></li>
        <li><a href="tarsak.html">Ügyfelek</a></li>
        <li><a href="mi.html">Rólunk</a></li>
        <li><a href="index5.php" class="aktiv">Kapcsolat</a></li>
        <li><a href="karrier.php">Karrier</a></li>
    </ul>
</nav>

<div class="takar"></div>
<script src="style.js"></script>
</body>
</html>